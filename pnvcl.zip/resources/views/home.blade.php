@extends('layouts.template')
@section('title', 'Programa Nacional de Vigilancia y Control de la Lepra')

@section('content')
<h1>Programa Nacional de Vigilancia y Control de la Lepra<h1>

    
    

<script type="text/javaScript">

    $( document ).ready(function() {

        
    });
</script>
@endsection()



