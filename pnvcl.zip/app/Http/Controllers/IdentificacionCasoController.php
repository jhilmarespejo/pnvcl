<?php

namespace App\Http\Controllers;

use App\Models\identificacion_caso;
use Illuminate\Http\Request;

class IdentificacionCasoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\identificacion_caso  $identificacion_caso
     * @return \Illuminate\Http\Response
     */
    public function show(identificacion_caso $identificacion_caso)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\identificacion_caso  $identificacion_caso
     * @return \Illuminate\Http\Response
     */
    public function edit(identificacion_caso $identificacion_caso)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\identificacion_caso  $identificacion_caso
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, identificacion_caso $identificacion_caso)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\identificacion_caso  $identificacion_caso
     * @return \Illuminate\Http\Response
     */
    public function destroy(identificacion_caso $identificacion_caso)
    {
        //
    }
}
