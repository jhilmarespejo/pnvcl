<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RedSalud extends Model
{
    use HasFactory;
    protected $table = 'red_salud';
}
