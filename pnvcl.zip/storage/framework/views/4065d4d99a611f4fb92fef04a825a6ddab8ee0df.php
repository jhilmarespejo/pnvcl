

<select class="form-select" id="provincias" name="provincia">
    <option selected disabled>Seleccione...</option>
    <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($provincia->id); ?>"><?php echo e($provincia->provincia); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>


<script type="text/javaScript">
    $( document ).ready(function() {
        
       $('#provincias').change(function (params) {
           
        var params= $('#provincias').val();
                $.ajax({
                    data:  {'provincia_id':params, 'q': 'municipios'},
                    url:   '/servicio/show',
                    headers: {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'},
                    type:  'post',
                    beforeSend: function () { },
                    success:  function (response) {                	
                        $('#municipios').remove();
                        $('#servs_salud').remove();
                        $('#redes_salud').remove();
                        $('#datos_personales_servicio_salud_id').val('');	
                        $(".municipios").html(response);

                    },
                    error:function(){
                        alert("error")
                    }
                });
        })
        
    });
    
    
</script><?php /**PATH C:\wamp64\www\pnvcl\resources\views/servicios/provincias.blade.php ENDPATH**/ ?>