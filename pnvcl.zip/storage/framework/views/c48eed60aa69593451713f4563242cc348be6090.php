<div class="col">
    <input type="hidden" name="tratamiento[datos_personales_id]" value="xxx" >
    <label class="form-label" >9.1 Traramiento anterior por:</label>
    <input type="date" name="bacteriologia[fecha_muestra]" value="<?php echo e(old('bacteriologia.fecha_muestra')); ?>" id="" class="form-control" placeholder="Fecha de toma de muestra" data-bs-toggle="tooltip" data-bs-placement="top" title="Fecha de toma de muestra">
    <?php $__errorArgs = ['bacteriologia.fecha_muestra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH C:\wamp64\www\pnvcl\resources\views/forms/tratamiento.blade.php ENDPATH**/ ?>