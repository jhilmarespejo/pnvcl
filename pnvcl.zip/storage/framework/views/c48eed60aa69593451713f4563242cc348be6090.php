<fieldset class="field-border col">
   <div class="col">
        
        <label class="form-label" ><strong>9.1 Traramiento anterior por:</strong></label>
        <br>
        <select name="tratamiento[tto_anterior]" id="" class="form-select">
            <option value="" disabled <?php echo e((old('tratamiento.tto_anterior') == '')? 'selected':''); ?> >Seleccione</option>
            <option value="Abandono" <?php echo e((old('tratamiento.tto_anterior') == 'Abandono')? 'selected':''); ?>>Abandono</option>
            <option value="Fracaso terapéutico" <?php echo e((old('tratamiento.tto_anterior') == 'Fracaso terapéutico')? 'selected':''); ?>>Fracaso terapéutico</option>
            <option value="Recaída" <?php echo e((old('tratamiento.tto_anterior') == 'Recaída')? 'selected':''); ?>>Recaída</option>
            <option value="Ninguno" <?php echo e((old('tratamiento.tto_anterior') == 'Ninguno')? 'selected':''); ?>>Ninguno</option>
        </select>
        <?php $__errorArgs = ['tratamiento.tto_anterior'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   </div>
   <div class="col ">
        <label class="form-label" >Esquema:</label>

        <input type="hidden" name="tratamiento[anterior_multibacilar]" value="">
        <input class="form-check-input" type="checkbox" name="tratamiento[anterior_multibacilar]" value="Si">
        <label class="form-check-label" for="lepromatosa">Multibacilar</label>


        <input type="hidden" name="tratamiento[anterior_paucibacilar]" value="">
        <input class="form-check-input" type="checkbox" name="tratamiento[anterior_paucibacilar]" value="Si">
        <label class="form-check-label" for="dimofa">Paucibacilar</label>
</fieldset>
    
    


<fieldset class="field-border col">
    <div class="row">
        <label class="form-label" ><strong>9.2 Tratamiento actual</strong></label>

        <div class="row">
            <label class="col" >Fecha inicio</label>
            <input type="date" name="tratamiento[actual_fecha_inicio]" value="<?php echo e(old('tratamiento.actual_fecha_inicio')); ?>" id="" class="col form-control" placeholder="Fecha de inicio del tratamiento" data-bs-toggle="tooltip" data-bs-placement="top" title="Fecha de inicio del tratamiento">
            <?php $__errorArgs = ['tratamiento.actual_fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>

        <div class="col">
            <label class=" " >Esquema:</label>
           
                <input type="hidden" name="tratamiento[actual_multibacilar]" value="">
                <input class="form-check-input" type="checkbox" name="tratamiento[actual_multibacilar]" value="Si">
                <label class="form-check-label" for="lepromatosa">Multibacilar</label>

                <input type="hidden" name="tratamiento[actual_paucibacilar]" value="">
                <input class="form-check-input" type="checkbox" name="tratamiento[actual_paucibacilar]" value="Si">
                <label class="form-check-label" for="dimofa">Paucibacilar</label>
        </div>
   </div>
</fieldset><?php /**PATH C:\wamp64\www\pnvcl\resources\views/forms/tratamiento.blade.php ENDPATH**/ ?>