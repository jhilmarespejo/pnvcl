


<?php if(isset($provincias)): ?>
    
<select class="form-select" id="provincia<?php echo e($position); ?>" name="">
    <option selected disabled>Seleccione...</option>
    <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($provincia->id); ?>"><?php echo e($provincia->provincia); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<script type="text/javaScript">
    $( document ).ready(function() {
        
    $('#provincia0, #provincia1, #provincia2').change(function (params) {
        var params= $(this).val();
        var actual_control = event.target.id.toString();
        var targer_control='';
                $.ajax({
                    data:  {'provincia_id':params, 'q': 'municipios', 'position': actual_control},
                    url:   '/residencia/show',
                    headers: {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'},
                    type:  'post',
                    beforeSend: function () { 
                        if(actual_control == 'provincia0'){
                            targer_control = "#municipio_anterior0";
                          }
                          if(actual_control == 'provincia1'){
                            targer_control = "#municipio_anterior1";
                          }
                          if(actual_control == 'provincia2'){
                            targer_control = "#municipio_anterior2";
                          }
                    },
                    success:  function (response) {                	
                        //$('#municipio_anterior').remove();
                        $(targer_control).html(response);
                    },
                    error:function(){
                        alert("error")
                    }
                });
        })
    });    
</script>
<?php endif; ?>

<?php if(isset($municipios)): ?>
<select class="form-select" id="municipios<?php echo e($position); ?>" name="">
    <option selected disabled>Seleccione...</option>
    <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($municipio->id); ?>" title="<?php echo e($municipio->municipio); ?>"><?php echo e($municipio->municipio); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<script type="text/javaScript">
    $( document ).ready(function() {
        $('#municipios0, #municipios1, #municipios2').change(function (params) {
            var params= $(this).val();
            var actual_control = event.target.id.toString();
            var targer_control='';
            if(actual_control == 'municipios0'){
                targer_control = "#municipio_id0";
            }
            if(actual_control == 'municipios1'){
                targer_control = "#municipio_id1";
            }
            if(actual_control == 'municipios2'){
                targer_control = "#municipio_id2";
            }
            
            $(targer_control).val( params );

        })
    });
</script>
<?php endif; ?>


<?php /**PATH C:\wamp64\www\pnvcl\resources\views/residenciaAnterior/options.blade.php ENDPATH**/ ?>