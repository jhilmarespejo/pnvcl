<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel=StyleSheet href="/bootstrap5/css/bootstrap.css" type="text/css">
    <link rel=StyleSheet href="/bootstrap5/css/custom.css" type="text/css">
    <script src="/bootstrap5/js/jquery.min.js"></script>
    <script src="/bootstrap5/js/bootstrap.bundle.min.js"></script>
  
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
    integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
    crossorigin=""/>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
   integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
   crossorigin=""></script>

    <script src="/maps/index.js"></script>

    

    <title>.:<?php echo $__env->yieldContent('title'); ?>:.</title>

</head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container-fluid ">
        <a class="navbar-brand" href="#">Menú: </a>
        
        <?php if(Auth::check()): ?>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <h4><a class="nav-link" aria-current="page" href="/paciente/create">Nuevo Paciente</a><h3>
              </li>
              <li class="nav-item">
                <h4><a class="nav-link" href="#">Control de Contactos</a></h4>
              </li>
            </ul>
            
          </div>
        <?php endif; ?>
        
      
        <div class="dropdown" id="navbarSupp  ortedContent">
          <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
            <?php if( Auth::check() ): ?>
              <?php echo e(Auth::user()->name); ?>

            <?php else: ?>
                Opciones
            <?php endif; ?>
          </a>
          <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
              <!-- Authentication Links -->
              <?php if(auth()->guard()->guest()): ?>
                  <?php if(Route::has('login')): ?>
                      <li>
                          <a class="dropdown-item" href="<?php echo e(route('login')); ?>"><?php echo e(__('Ingresar')); ?></a>
                      </li>
                  <?php endif; ?>

                  
              <?php else: ?>
                  
                  <li>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                              onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                              <?php echo e(__('Salir')); ?>

                          </a>
                          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                              <?php echo csrf_field(); ?>
                          </form>
                  </li>
              <?php endif; ?>
          </ul>
        </div>
      </div>
  </nav>


  

    <div class="container container-md border border-2 rounded img-fluid body-container">
        <div class="row">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>
</body>
</html>



<script type="text/javaScript">
  $(document).ready(function(){
// FUNCTION FOR TOOLTIPS
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl)
    });
// FUNCTION FOR VALIDATE FORM CLIENT SIDE
// Example starter JavaScript for disabling form submissions if there are invalid fields
      (function () {
        'use strict'
        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.querySelectorAll('.needs-validation')

        // Loop over them and prevent submission
        Array.prototype.slice.call(forms)
          .forEach(function (form) {
            form.addEventListener('submit', function (event) {
              if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
              }

              form.classList.add('was-validated')
            }, false)
          })
      })()
  });
</script><?php /**PATH C:\wamp64\www\pnvcl\resources\views/layouts/template.blade.php ENDPATH**/ ?>