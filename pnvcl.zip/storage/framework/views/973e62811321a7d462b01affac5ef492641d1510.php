<div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-center" id="controlContactosLabel">3. Control de contactos</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <table class="table table-responsive table-bordered text-center">
              <thead>
                  <tr>
                      <th>Departamento</th>
                      <th>Provincia</th>
                      <th>Municipio</th>
                      <th>Tiempo de residencia</th>
                  </tr>
              </thead>
              <tbody>
                <?php for ($i=0; $i <= 2; $i++): ?>
                <tr>
                    <input type="hidden" name="recidencia_anterior[<?php echo e($i); ?>][municipio_id]" value="">
                    <td><input name="" type="text"></td>
                    <td><input name="" type="text"></td>
                    <td><input name="" type="text"></td>
                    <td>
                        <input name="recidencia_anterior[<?php echo e($i); ?>][tiempo]" type="number" min="0" max="100" class="col-3">
                        <select class="col-4" name="recidencia_anterior[<?php echo e($i); ?>][medida]" >
                            <option selected disabled>Seleccione...</option>
                            <option value="Meses">Meses</option>
                            <option value="Años">Años</option>
                        </select>
                    </td>
                </tr>               
                <?php endfor; ?>
                       
              </tbody>
          </table>
        
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-success" data-bs-dismiss="modal">Guardar</button>
      </div>
    </div>
  </div>

  <script type="text/javaScript">
    $(document).ready(function(){
        
    });
  </script><?php /**PATH C:\wamp64\www\pnvcl\resources\views/forms/residenciaAnterior.blade.php ENDPATH**/ ?>