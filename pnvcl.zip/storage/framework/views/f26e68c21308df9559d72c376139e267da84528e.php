<?php $__env->startSection('title', 'Programa Nacional de Vigilancia y Control de la Lepra'); ?>

<?php $__env->startSection('content'); ?>
<h1>Programa Nacional de Vigilancia y Control de la Lepra<h1>

    
    

<script type="text/javaScript">

    $( document ).ready(function() {

        
    });
</script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\pnvcl\resources\views/home.blade.php ENDPATH**/ ?>