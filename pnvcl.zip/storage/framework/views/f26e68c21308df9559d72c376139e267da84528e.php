<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Panel')); ?></div>
                
                <div class="card-body">
                    
                    <?php if(Auth::user()): ?>

                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-info" role="alert">
                                <strong><?php echo e(Session::get('success')); ?></strong>
                            </div>                    
                        <?php else: ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                                Bienvenido <strong><?php echo e(Auth::user()->name); ?></strong>
                                <br>
                            </div>  
                        <?php endif; ?>


                        
                    <?php else: ?>
                        <div class="alert alert-danger" role="alert">
                            Bienvenido <strong> Porfavor inicie Sesión</strong>
                        </div>
                    <?php endif; ?>

                   
                </div>
            </div>
        </div>
    </div>



    
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\pnvcl\resources\views/home.blade.php ENDPATH**/ ?>