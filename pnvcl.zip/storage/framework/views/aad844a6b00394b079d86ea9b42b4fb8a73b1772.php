<div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="controlContactosLabel">3. Control de contactos</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <table class="table table-responsive table-bordered text-center">
              <thead>
                  <tr>
                      <th>Apellidos</th>
                      <th>Nombres</th>
                      <th>Edad</th>
                      <th>Parentesco o Afinidad</th>
                      <th>Antecedente de lepra</th>
                      <th>Fecha</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td><input type="text"></td>
                      <td><input type="text"></td>
                      <td><input type="number"></td>
                      <td>
                          <select class="form-select" placeholder="">
                          <option selected disabled>Seleccione...</option>
                          <option value="Pariente">Pariente</option>
                          <option value="Vecino">Vecino</option>
                          <option value="Amigo">Amigo</option>
                          <option value="Otro">Otro</option>
                      </select>
                      </td>
                      <td>
                          <select class="form-select" placeholder="">
                              <option selected disabled>Seleccione...</option>
                              <option value="Si">Si</option>
                              <option value="No">No</option>
                          </select>
                      </td>
                      <td><input type="date"></td>
                  </tr>
                  <tr>
                      <td><input type="text"></td>
                      <td><input type="text"></td>
                      <td><input type="number"></td>
                      <td>
                          <select class="form-select" placeholder="">
                          <option selected disabled>Seleccione...</option>
                          <option value="Pariente">Pariente</option>
                          <option value="Vecino">Vecino</option>
                          <option value="Amigo">Amigo</option>
                          <option value="Otro">Otro</option>
                      </select>
                      </td>
                      <td>
                          <select class="form-select" placeholder="">
                              <option selected disabled>Seleccione...</option>
                              <option value="Si">Si</option>
                              <option value="No">No</option>
                          </select>
                      </td>
                      <td><input type="date"></td>
                  </tr>
                  <tr>
                      <td><input type="text"></td>
                      <td><input type="text"></td>
                      <td><input type="number"></td>
                      <td>
                          <select class="form-select" placeholder="">
                          <option selected disabled>Seleccione...</option>
                          <option value="Pariente">Pariente</option>
                          <option value="Vecino">Vecino</option>
                          <option value="Amigo">Amigo</option>
                          <option value="Otro">Otro</option>
                      </select>
                      </td>
                      <td>
                          <select class="form-select" placeholder="">
                              <option selected disabled>Seleccione...</option>
                              <option value="Si">Si</option>
                              <option value="No">No</option>
                          </select>
                      </td>
                      <td><input type="date"></td>
                  </tr>
              </tbody>
          </table>
        
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-success">Guardar</button>
      </div>
    </div>
  </div><?php /**PATH C:\wamp64\www\pnvcl\resources\views/forms/controlcontactos.blade.php ENDPATH**/ ?>