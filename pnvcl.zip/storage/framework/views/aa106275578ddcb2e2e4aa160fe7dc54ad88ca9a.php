

<?php if(isset($provincias)): ?>
    
    <select class="form-select" id="provincias" name="provincia">
        <option selected disabled>Seleccione...</option>
        <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($provincia->id); ?>"><?php echo e($provincia->provincia); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <script type="text/javaScript">
        $( document ).ready(function() {
            
        $('#provincias').change(function (params) {
            
            var params= $('#provincias').val();
                    $.ajax({
                        data:  {'provincia_id':params, 'q': 'municipios'},
                        url:   '/servicio/show',
                        headers: {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'},
                        type:  'post',
                        beforeSend: function () { },
                        success:  function (response) {                	
                            $('#municipios').remove();
                            $('#servs_salud').remove();
                            $('#redes_salud').remove();
                            $('#datos_personales_servicio_salud_id').val('');	
                            $(".municipios").html(response);
                        },
                        error:function(){
                            alert("error")
                        }
                    });
            })
        });    
    </script>
<?php endif; ?>

<?php if(isset($municipios)): ?>
    <select class="form-select" id="municipios" name="municipio">
        <option selected disabled>Seleccione...</option>
        <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option data-toggle="tooltip" data-container="#tooltip_container" value="<?php echo e($municipio->id); ?>" title="<?php echo e($municipio->municipio); ?>"><?php echo e($municipio->municipio); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <script type="text/javaScript">
        $( document ).ready(function() {
        $('#municipios').change(function (params) {
            var params= $(this).val();
                    $.ajax({
                        data:  {'municipio_id':params, 'q': 'sevicios_salud'},
                        url:   '/servicio/show',
                        headers: {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'},
                        type:  'post',
                        beforeSend: function () { },
                        success:  function (response) {                	
                            $('#servs_salud').remove();
                            $('#redes_salud').remove();     
                            $('#datos_personales_servicio_salud_id').val('');
                            $(".serv_salud").html(response);

                        },
                        error:function(){
                            alert("error")
                        }
                    });
            })
        });
    </script>
<?php endif; ?>





<?php if(isset($servicios_salud)): ?>
    <select class="form-select" id="servs_salud" name="serv_salud">
        <option selected disabled>Seleccione...</option>
        <?php $__currentLoopData = $servicios_salud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio_salud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($servicio_salud->id); ?>" title="<?php echo e($servicio_salud->serv_salud); ?>"><?php echo e($servicio_salud->serv_salud); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>

    <script type="text/javaScript">
        $( document ).ready(function() {
        $('#servs_salud').change(function (params) {
            var params= $(this).val();
                    $.ajax({
                        data:  {'id':params, 'q': 'red_salud'},
                        url:   '/servicio/show',
                        headers: {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'},
                        type:  'post',
                        beforeSend: function () { },
                        success:  function (response) {      
                            
                            $('#redes_salud').remove();     
                            $('#datos_personales_servicio_salud_id').val(params);	
                            $('#servicio_salud_notifica').val($("#servs_salud option:selected" ).text());
                            $(".red_salud").html(response);
                            
                        },
                        error:function(){
                            alert("error")
                        }
                    });
            })
        });
    </script> 
<?php endif; ?>


<?php if(isset($red_salud)): ?>
    <?php $__currentLoopData = $red_salud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <input type="text" name="" id="redes_salud" class="form-control" disabled value="<?php echo e($red->red_salud); ?>"> 
<?php endif; ?><?php /**PATH C:\wamp64\www\pnvcl\resources\views/datosPersonales/servSalud.blade.php ENDPATH**/ ?>