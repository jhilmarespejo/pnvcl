<select class="form-select" id="municipios" name="municipio">
    <option selected disabled>Seleccione...</option>
    <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option data-toggle="tooltip" data-container="#tooltip_container" value="<?php echo e($municipio->id); ?>" title="<?php echo e($municipio->municipio); ?>"><?php echo e($municipio->municipio); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>




<script type="text/javaScript">
    $( document ).ready(function() {
       $('#municipios').change(function (params) {
        var params= $(this).val();
                $.ajax({
                    data:  {'municipio_id':params, 'q': 'sevicios_salud'},
                    url:   '/servicio/show',
                    headers: {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'},
                    type:  'post',
                    beforeSend: function () { },
                    success:  function (response) {                	
                        $('#servs_salud').remove();
                        $('#redes_salud').remove();     
                        $('#datos_personales_servicio_salud_id').val('');
                        $(".serv_salud").html(response);

                    },
                    error:function(){
                        alert("error")
                    }
                });
        })
    });
</script><?php /**PATH C:\wamp64\www\pnvcl\resources\views/servicios/municipios.blade.php ENDPATH**/ ?>