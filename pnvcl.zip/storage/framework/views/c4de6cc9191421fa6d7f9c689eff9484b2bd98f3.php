

<?php $__env->startSection('title', 'Nuevo Paciente'); ?>



<?php $__env->startSection('content'); ?>

<h3 class="text-center">REGISTRO DE PACIENTE</h3>
    <div class="containet mb-4">
        <fieldset class="row entry field-border">
            <legend class="field-border">1. Datos generales</legend>
            <div class="col xs sm md">
                <label class="form-label">Sedes</label>
                <select class="form-select"  placeholder="" name="">
                    <option selected disabled>Seleccione...</option>
                    <option value="1">Beni</option>
                    <option value="2">Pando</option>
                    <option value="3">Santa Cruz</option>
                    <option value="1">Cochabamba</option>
                    <option value="2">Tarija</option>
                    <option value="3">Chuquisaca</option>
                    
                </select>
            </div>
            
            <div class="col xs sm md">
                <label class="form-label">Provincia</label>
                <input type="text" name="" id="" class="form-control">
            </div>
            
            <div class="col xs sm md">
                <label class="form-label">Municipio</label>
                <input type="text" name="" id="" class="form-control">
            </div>
            
            <div class="col xs sm md">
                <label class="form-label">Servicio de Salud</label>
                <input type="text" name="" id="" class="form-control">
            </div>
            
            <div class="col xs sm md">
                <label class="form-label">Red de Salud</label>
                <input type="text" name="" id="" class="form-control">
            </div>
        </fieldset>
    </div>
<form action="<?php echo e(route('paciente.store')); ?>" method="POST" >
    <?php echo csrf_field(); ?>
    
    <?php echo $__env->make('forms.datosPersonales', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container row mb-2">
        <fieldset class="field-border row ">
                <legend class="col field-border col ">3. Control de contactos</legend>
                <button type="button" class="col btn btn-primary " data-bs-toggle="modal" data-bs-target="#controlContactos" data-bs-whatever="@mdo">Agregar datos de contactos</button>
        </fieldset>
    </div>
    
    <div class="container row">
        <fieldset class="field-border row">
            <legend class="field-border">4. Datos clínicos</legend>
            <div>
                <label class="form-label" > <br> Inicio de signos y/o síntomas año</label>
                <input type="number" name="datos_clinicos[inicio_sintomas]" min="2010" max="2021" value="<?php echo e(old('datos_clinicos.inicio_sintomas')); ?>" id="" class="form-control" placeholder="Inicio de signos y/o síntomas año" data-bs-toggle="tooltip" data-bs-placement="top" title="Inicio de signos y/o síntomas año">
                <?php $__errorArgs = ['datos_clinicos.inicio_sintomas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col">
                <label class="form-label" >Tiempo de evolución en años o meses</label>
                <input type="number" name="datos_clinicos[tiempo_evolucion_cantidad]" min="0" max="100" value="<?php echo e(old('datos_clinicos.tiempo_evolucion_cantidad')); ?>" id="" class="form-control" placeholder="Tiempo de evolución en años o meses" data-bs-toggle="tooltip" data-bs-placement="top" title="Tiempo de evolución en años o meses">
                <?php $__errorArgs = ['datos_clinicos.tiempo_evolucion_cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col">
                <label class="form-label" ><br><br><br></label>
                <select name="datos_clinicos[tiempo_evolucion_unidad]" data-bs-toggle="tooltip" data-bs-placement="top" title="Años o Meses" class="form-select">
                    <option disabled <?php echo e((old('datos_clinicos.tiempo_evolucion_unidad') == '')? 'selected':''); ?> >Seleccione...</option>
                    <option value="Meses" <?php echo e((old('datos_clinicos.tiempo_evolucion_unidad') == 'Meses')? 'selected':''); ?> >Meses</option>
                    <option value="Años" <?php echo e((old('datos_clinicos.tiempo_evolucion_unidad') == 'Años')? 'selected':''); ?> >Años</option>
                </select>
                <?php $__errorArgs = ['datos_clinicos.tiempo_evolucion_unidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="row mt-4">
                <div class="col">
                    <label class="form-label" >Descripción de los primeros signos y/o síntomas</label>
                    <textarea class="form-control" name="datos_clinicos[descripcion_primeros_signos]" id="" class="form-control" placeholder="Descripción de los primeros signos" data-bs-toggle="tooltip" data-bs-placement="top" title="Descripción de los primeros signos"><?php echo e(old('datos_clinicos.descripcion_primeros_signos')); ?></textarea>
                    <?php $__errorArgs = ['datos_clinicos.descripcion_primeros_signos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col">
                    <label class="form-label" >Cuadro clínico actual (exploración general, signos y/o síntomas específicos y características de lesiones) </label>
                    <textarea class="form-control" name="datos_clinicos[cuadro_clinico_actual]" id="" class="form-control" placeholder="Cuadro clínico actual (exploración general, signos y/o síntomas específicos y características de lesiones" data-bs-toggle="tooltip" data-bs-placement="top" title="Cuadro clínico actual (exploración general, signos y/o síntomas específicos y características de lesiones"><?php echo e(old('datos_clinicos.cuadro_clinico_actual')); ?></textarea>
                    <?php $__errorArgs = ['datos_clinicos.cuadro_clinico_actual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </fieldset>
    </div>
    
    <div class="container row mt-3">
        <fieldset class="field-border row">
            <legend class="field-border">5. Bacteriología</legend>
            <div class="row">
                <div class="col">
                    <label class="form-label" >Fecha de toma de muestra</label>
                    <input type="date" name="bacteriologia[fecha_muestra]" value="<?php echo e(old('bacteriologia.fecha_muestra')); ?>" id="" class="form-control" placeholder="Fecha de toma de muestra" data-bs-toggle="tooltip" data-bs-placement="top" title="Fecha de toma de muestra">
                    <?php $__errorArgs = ['bacteriologia.fecha_muestra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col">
                    <label class="form-label" >Laboratorio </label>
                    <input type="text" name="bacteriologia[laboratorio]" value="<?php echo e(old('bacteriologia.laboratorio')); ?>" id="" class="form-control" placeholder="Laboratorio" data-bs-toggle="tooltip" data-bs-placement="top" title="Laboratorio">
                    <?php $__errorArgs = ['bacteriologia.laboratorio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row"></div>
            <div class="row mt-3">
                <div class="col">
                    <label class="form-label" >Linfa obtenida de:</label>
                </div>
                <div class="col">
                    <select class="form-select col" name="bacteriologia[linfa]" data-bs-toggle="tooltip" data-bs-placement="top" title="Linfa obtenida de" class="form-select">
                        <option disabled <?php echo e((old('bacteriologia.linfa') == '')? 'selected':''); ?>>Seleccione...</option>
                        <option value="Lobulo de la oreja" <?php echo e((old('bacteriologia.linfa') == 'Lobulo de la oreja')? 'selected':''); ?>>Lóbulo de la oreja</option>
                        <option value="Lesion" <?php echo e((old('bacteriologia.linfa') == 'Lesion')? 'selected':''); ?>>Lesión</option>
                        <option value="Codo" <?php echo e((old('bacteriologia.linfa') == 'Meses')? 'selected':''); ?>>Codo</option>
                    </select>
                    <?php $__errorArgs = ['bacteriologia.linfa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row mb-3 mt-3"><label for=""><strong>Resultado laboratorial:</strong></label></div>
            <div class="col">
                <label class="form-label" >Fecha de resultado</label>
                <input type="date" name="bacteriologia[fecha_resultado]" value="<?php echo e(old('bacteriologia.fecha_resultado')); ?>" id="" class="form-control" placeholder="Fecha de resultado" data-bs-toggle="tooltip" data-bs-placement="top" title="Fecha de resultado">
                <?php $__errorArgs = ['bacteriologia.fecha_resultado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col">
                <label class="form-label" >Lóbulo de la oreja</label>
                <select class="form-select" name="bacteriologia[resultado_lobulo_oreja]" data-bs-toggle="tooltip" data-bs-placement="top" title="Resultado: lóbulo de la oreja" class="form-select">
                    <option disabled <?php echo e((old('bacteriologia.resultado_lobulo_oreja') == '')? 'selected':''); ?>>Seleccione...</option>
                    <option value="Positivo" <?php echo e((old('bacteriologia.resultado_lobulo_oreja') == 'Positivo')? 'selected':''); ?>>Positivo</option>
                    <option value="Negativo" <?php echo e((old('bacteriologia.resultado_lobulo_oreja') == 'Negativo')? 'selected':''); ?>>Negativo</option>
                </select>
                <?php $__errorArgs = ['bacteriologia.resultado_lobulo_oreja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="row mt-2"></div>
            <div class="col">
                <label class="form-label" >Lessión</label>
                <select class="form-select" name="bacteriologia[resultado_lesion]" data-bs-toggle="tooltip" data-bs-placement="top" title="Resultado: Lessión" class="form-select">
                    <option disabled <?php echo e((old('bacteriologia.resultado_lesion') == '')? 'selected':''); ?>>Seleccione...</option>
                    <option value="Positivo" <?php echo e((old('bacteriologia.resultado_lesion') == 'Positivo')? 'selected':''); ?>>Positivo</option>
                    <option value="Negativo" <?php echo e((old('bacteriologia.resultado_lesion') == 'Negativo')? 'selected':''); ?>>Negativo</option>
                </select>
                <?php $__errorArgs = ['bacteriologia.resultado_lesion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col">
                <label class="form-label" >Codo</label>
                <select class="form-select" name="bacteriologia[resultado_codo]" data-bs-toggle="tooltip" data-bs-placement="top" title="Resultado: Codo" class="form-select">
                    <option disabled <?php echo e((old('bacteriologia.resultado_codo') == '')? 'selected':''); ?>>Seleccione...</option>
                    <option value="Positivo" <?php echo e((old('bacteriologia.resultado_codo') == 'Positivo')? 'selected':''); ?>>Positivo</option>
                    <option value="Negativo" <?php echo e((old('bacteriologia.resultado_codo') == 'Negativo')? 'selected':''); ?>>Negativo</option>
                </select>
                <?php $__errorArgs = ['bacteriologia.resultado_codo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </fieldset>
        <fieldset class="field-border row mt-3">
            <legend class="field-border mb-3">6. Histopatolog&iacute;a (si corresponde o es necesario)</legend>
            <div class="col">
                

                <textarea class="form-control" name="histopatologia[laboratorio_informe]" id="" class="form-control" placeholder="Laboratorio que realiza el informe" data-bs-toggle="tooltip" data-bs-placement="top" title="Laboratorio que realiza el informe"><?php echo e(old('histopatologia.laboratorio_informe')); ?></textarea>
                <?php $__errorArgs = ['histopatologia.laboratorio_informe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>
            <div class="col">
                

                <textarea class="form-control" name="histopatologia[resultado_histopatologico]" id="" class="form-control" placeholder="Resultado histopatológico" data-bs-toggle="tooltip" data-bs-placement="top" title="Resultado histopatológico"><?php echo e(old('histopatologia.resultado_histopatologico')); ?></textarea>
                <?php $__errorArgs = ['histopatologia.resultado_histopatologico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </fieldset>
    </div>

    
    <?php echo $__env->make('forms.diagnosticoClinico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="container row mt-2">
        <fieldset class="field-border row ">
                <legend class="col field-border col ">8. Registro de discapacidades</legend>
                <button type="button" class="col btn btn-primary " data-bs-toggle="modal" data-bs-target="#discapacidades" data-bs-whatever="@mdo">Agregar registros</button>
        </fieldset>
         
            <div class="modal fade" id="discapacidades" tabindex="-1" aria-labelledby="discapacidadLabel" aria-hidden="true">
                <?php echo $__env->make('forms.discapacidades', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            </div>
        
    </div>
    
    <div class="container row mt-2">
        <fieldset class="field-border row ">
            <legend class="col field-border col ">9. Tratamiento</legend>
            <?php echo $__env->make('forms.tratamiento', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
        </fieldset>

    </div>

    
    
        <div class="modal fade" id="controlContactos" tabindex="-1" aria-labelledby="controlContactosLabel" aria-hidden="true">
            <?php echo $__env->make('forms.controlContactos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
        </div>
    

    
    <div class="modal fade" id="residenciaanterior" tabindex="-1" aria-labelledby="controlContactosLabel" aria-hidden="true">
        <?php echo $__env->make('forms.residenciaAnterior', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    </div>
    
    <button type="submit" class="btn btn-success btn-lg"  >Enviar</button>
</form>
<script type="text/javaScript">
    $( document ).ready(function() {
       
   
  });
</script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\pnvcl\resources\views/datosPersonales/create.blade.php ENDPATH**/ ?>