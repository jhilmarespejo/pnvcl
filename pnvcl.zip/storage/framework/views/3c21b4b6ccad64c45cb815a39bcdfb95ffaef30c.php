<div class="container row mt-3 ">
    <fieldset class="field-border row">
        <legend class="field-border">7. Diagnóstico clínico</legend>
        <fieldset class="field-border col">
            <legend class="fs-6">7.1. Clasificación clínica</legend>
            <div class="row">
                <div class="row">
                    <label for="" class="col">Fecha de diagnóstico</label>
                    <input type="date" name="diagnostico[fecha_diagnostico]" value="<?php echo e(old('diagnostico.fecha_diagnostico')); ?>"data-bs-toggle="tooltip" data-bs-placement="top" id="search" class="form-control col" placeholder="Fecha de diagnóstico" title="Fecha de diagnóstico">
                        <?php $__errorArgs = ['diagnostico.fecha_diagnostico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="fs-8 text-danger"> * <?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col">
                    <strong class="">Multibacilar</strong>
                    <div class="mt-3">
                        <input type="hidden" name="diagnostico[multibacilar_lepromatosa]" value="">
                        <input class="form-check-input" type="checkbox" name="diagnostico[multibacilar_lepromatosa]" value="Si">
                        <label class="form-check-label" for="lepromatosa">Lepra lepromatosa</label>
                        
                        <br>
                        
                        <input type="hidden" name="diagnostico[multibacilar_dimofa]" value="">
                        <input class="form-check-input" type="checkbox" name="diagnostico[multibacilar_dimofa]" value="Si">
                        <label class="form-check-label" for="dimofa">Lepra dimofa</label>
                    </div>
                </div>
                <div class="col">
                    <strong class="">Paucibacilar</strong>
                    <div class="mt-3">
                        <input type="hidden" name="diagnostico[paucibacilar_tuberculoide]" value="">
                        <input class="form-check-input" type="checkbox" name="diagnostico[paucibacilar_tuberculoide]" value="Si">
                        <label class="form-check-label" for="lepromatosa">Lepra lepromatosa</label>
                        
                        <br>
                        
                        <input type="hidden" name="diagnostico[paucibacilar_indeterminada]" value="">
                        <input class="form-check-input" type="checkbox" name="diagnostico[paucibacilar_indeterminada]" value="Si">
                        <label class="form-check-label" for="dimofa">Lepra dimofa</label>
                    </div>
                </div>
            </div>

        </fieldset>

        <fieldset class="field-border col">
            <legend class="fs-6">7.2. Localizacion de las lesiones cutáneas y nerviosas</legend>
                <div class="row mb-2">
                    <div class="col"> 
                        <textarea name="diagnostico[cabeza]" id="" cols="23" rows="1" id=""  data-bs-toggle="tooltip" data-bs-placement="top" title="Cabeza" placeholder="Cabeza"><?php echo e(old('diagnostico.cabeza')); ?></textarea>
                        <?php $__errorArgs = ['diagnostico.cabeza'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="col fs-8 text-danger"> * <?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    &NonBreakingSpace;
                    <div class="col"> 
                        <textarea name="diagnostico[tronco]" id="" cols="23" rows="1" id="" data-bs-toggle="tooltip" data-bs-placement="top" title="Tronco" placeholder="Tronco"><?php echo e(old('diagnostico.tronco')); ?></textarea>
                        <?php $__errorArgs = ['diagnostico.tronco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="col fs-8 text-danger"> * <?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col"> 
                        <textarea name="diagnostico[ext_superiores]" id="" cols="23" rows="1"  data-bs-toggle="tooltip" data-bs-placement="top" title="Extremidades superiores" placeholder="Extremidades superiores"><?php echo e(old('diagnostico.ext_superiores')); ?></textarea>
                        <?php $__errorArgs = ['diagnostico.ext_superiores'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="col fs-8 text-danger"> * <?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    &NonBreakingSpace;
                    <div class="col"> 
                        <textarea name="diagnostico[ext_inferiores]" id="" cols="23" rows="1"  data-bs-toggle="tooltip" data-bs-placement="top" title="Extremidades inferiores" placeholder="Extremidades inferiores"><?php echo e(old('diagnostico.ext_inferiores')); ?></textarea>
                        <?php $__errorArgs = ['diagnostico.ext_inferiores'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="col fs-8 text-danger"> * <?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
        </fieldset>
    </fieldset>
</div><?php /**PATH C:\wamp64\www\pnvcl\resources\views/datosPersonales/diagnosticoClinico.blade.php ENDPATH**/ ?>