<div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-center" id="controlContactosLabel">3. Control de contactos</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <table class="table table-responsive table-bordered ">
              <thead>
                  <tr>
                      
                      <th>Nombres</th>
                      <th>Apellidos</th>
                      <th>Edad</th>
                      <th>Parentesco o Afinidad</th>
                      <th>Antecedente de lepra</th>
                      <th>Fecha</th>
                  </tr>
              </thead>
              <tbody>

                <?php for ($i=0; $i <= 2; $i++): ?>
                  <tr>
                      <td><input name="control_contactos[<?php echo e($i); ?>][nombres]" type="text"></td>
                      <td><input name="control_contactos[<?php echo e($i); ?>][apellidos]" type="text"></td>
                      <td><input name="control_contactos[<?php echo e($i); ?>][edad]" type="number" min="0" ></td>
                      <td>
                          <select class="form-select" name="control_contactos[<?php echo e($i); ?>][parentesco]">
                          <option selected disabled>Seleccione...</option>
                          <option value="Pariente">Pariente</option>
                          <option value="Vecino">Vecino</option>
                          <option value="Otro">Otro</option>
                      </select>
                      </td>
                      <td>
                          <select class="form-select" name="control_contactos[<?php echo e($i); ?>][antecedente_lepra]">
                              <option selected disabled>Seleccione...</option>
                              <option value="Si">Si</option>
                              <option value="No">No</option>
                          </select>
                      </td>
                      <td><input name="control_contactos[<?php echo e($i); ?>][fecha_contacto]" type="date"></td>
                  </tr>
                <?php endfor; ?>
                  
               
                </tbody>
          </table>
        
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-success" data-bs-dismiss="modal">Guardar</button>
      </div>
    </div>
  </div><?php /**PATH C:\wamp64\www\pnvcl\resources\views/datosPersonales/controlContactos.blade.php ENDPATH**/ ?>